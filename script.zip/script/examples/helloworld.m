%% MATLAB hello world

% Print hello world
fprintf('hello world\n');
exit(0);
