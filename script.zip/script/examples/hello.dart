main() {
  print('Hello World!');
}
