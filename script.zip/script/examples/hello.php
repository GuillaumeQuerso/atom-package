<?php

echo "Hello, PHP\n";
echo 'PHP v' . phpversion();