## 0.1.0 - First Release
## 0.2.1 - Some language additions
## 0.2.2 - Language additions
- added support for all caps constants
## 0.4.0 - added support for html-base
updated for atom 1.0
## 0.8.0 - Added filetypes
