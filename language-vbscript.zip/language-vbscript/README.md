# language-vbscript package

Adds syntax highlighting and snippets for vbscript files to Atom.

Because some people need to edit old stuff...

Originally [converted](http://atom.io/docs/latest/converting-a-text-mate-bundle)
from the [ASP TextMate bundle](https://github.com/textmate/asp.tmbundle).

This is a work in progress. Feel free to fork and drop a merge request.
