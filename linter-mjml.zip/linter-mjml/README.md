# linter-mjml package

Atom linter plugin for [MJML](https://github.com/mjmlio/mjml). Requires [Atom Linter](https://atom.io/packages/linter).

![Screenshot of linter-mjml](https://cloud.githubusercontent.com/assets/570317/19561258/366cc3b0-96d8-11e6-9f44-44447ab41e9e.gif)

# Installation

Download the plugin through Atom packages or using the command line:
```
apm install linter-mjml
```

