## 1.0.0 - MJML Linter into Atom !
* Show MJML errors on `.mjml` file
